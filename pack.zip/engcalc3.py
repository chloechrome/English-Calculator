#GODHELPME INDUSTRIES(C) ENGLISH CALCULATOR 2.0
import random

#the word type selection function
def choicesfunc(xyz):
    xyz = xyz.lower().strip()
    if xyz in ["noun","n"]:
        return(random.choice(nouns))
    elif xyz in ["verb","v"]:
        return(random.choice(verbs))
    elif xyz in ["adjective","an"]:
        return(random.choice(adnouns))
    elif xyz in ["adverb","av"]:
        return(random.choice(adverbs))
    
    elif xyz == "a":
        return('a')
    elif xyz in ['the',"t"]:
        return('the')
    elif xyz in ["and","et"]:
        return('and')
    elif xyz in ['or',"o"]:
        return('or')
    elif xyz in ['then',"th"]:
        return('then')

print('----====GODHELPME INDUSTRIES(C) ENGLISH CALCULATOR 2.5====----\nLetter Codes:\n\tn == noun\n\tv == verb\n\tan == adnoun(adjective)\n\tav == adverb\n\ta == "a"\n\tt == "the"\n\tet == "and"\n\to == "or"\n\tth == "then"')

#words list (thx Book) + new selector
TYPE=input('Select wordset: [CL] Classic (default), [CE] Community, [DC] Draco.')
TYPE = TYPE.lower().strip()
if TYPE in ['cl','']:
    with open("CL/nouns.txt", "r") as f:
        nouns = [w.strip() for w in f.readlines()]
    with open("CL/verbs.txt", "r") as f:
        verbs = [w.strip() for w in f.readlines()]
    with open("CL/adnouns.txt", "r") as f:
        adnouns = [w.strip() for w in f.readlines()]
    with open("CL/adverbs.txt", "r") as f:
        adverbs = [w.strip() for w in f.readlines()]
elif TYPE=='ce'
    with open("CE/nouns.txt", "r") as f:
        nouns = [w.strip() for w in f.readlines()]
    with open("CE/verbs.txt", "r") as f:
        verbs = [w.strip() for w in f.readlines()]
    with open("CE/adnouns.txt", "r") as f:
        adnouns = [w.strip() for w in f.readlines()]
    with open("CE/adverbs.txt", "r") as f:
        adverbs = [w.strip() for w in f.readlines()]
elif TYPE=='dc':
    with open("DC/nouns.txt", "r") as f:
        nouns = [w.strip() for w in f.readlines()]
    with open("DC/verbs.txt", "r") as f:
        verbs = [w.strip() for w in f.readlines()]
    with open("DC/adnouns.txt", "r") as f:
        adnouns = [w.strip() for w in f.readlines()]
    with open("DC/adverbs.txt", "r") as f:
        adverbs = [w.strip() for w in f.readlines()]

#thanks Book
n = int(input("how many words? ").strip())
output = []
for i in range(n):
    t = input("noun, verb, adjective or adverb? ")
    output.append(choicesfunc(t))

print(str(" ".join(output)) + ".")

K = input("press return to close.")
