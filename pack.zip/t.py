import random





nouns = ["man", "woman", "person", "cat", "dog"]




def choicesfunc(xyz):
    xyz = xyz.lower().strip()
    if xyz == "n":
        return(random.choice(nouns))




n = int(input("how many words? ").strip())
output = "xxxx"
for i in range(n):
    t = input("noun, verb, adjective or adverb? ")

    output += " " + choicesfunc(t)

print(output.strip())
