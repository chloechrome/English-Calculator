#GODHELPME INDUSTRIES(C) ENGLISH CALCULATOR
import random
sbj = ["The man", "The woman", "The person", "The dog", "The cat", "Book", "Mono", "Infinity", "The apple", "The orange",]
vb = ["walked to", "ran to", "jogged to", "flew to", "hopped to", "fucking legged it to", "stabbed", "shot", "killed", "jumped over",]
obj = ["the man", "the woman", "the person", "the dog", "the cat", "Book", "Mono", "Infinity", "the apple", "the orange",]
adv = ["quickly", "slowly", "clumsily", "quietly", "loudly", "tiredly", "murderously", "savagely", "stupidly"]

print(random.choice(sbj), random.choice(vb), random.choice(obj), random.choice(adv), ".")
